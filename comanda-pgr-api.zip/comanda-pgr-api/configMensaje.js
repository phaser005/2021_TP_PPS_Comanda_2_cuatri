const nodemailer = require('nodemailer');

module.exports = (data) => {
	//para obtener OAuth2: https://stackoverflow.com/questions/24098461/nodemailer-gmail-what-exactly-is-a-refresh-token-and-how-do-i-get-one
	var transporter = nodemailer.createTransport({
		service: 'gmail',
		auth: {
			type: 'OAuth2',
			user: 'emailPropio',
			clientId: "idCliente",
			clientSecret: "llaveCliente",
			refreshToken: "refreshParaRefrescar",
			accessToken: "TokenDeAcceso"
		}
	});
	const mailOptions = {
		from: 'emailPropio',
		to: data.destinatario,
		subject: data.asunto,
		html: data.contenido
	};
	return transporter.sendMail(mailOptions).then(info =>{
		return info;
	}).catch(err =>{
		return err;
	});
}